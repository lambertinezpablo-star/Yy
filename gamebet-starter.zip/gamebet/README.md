# GameBet (Starter)

Este proyecto incluye:
- **frontend/** React + Vite + Tailwind (UI).
- **backend/** Node + Express (APIs básicas mock).
- **Capacitor** configurado para Android (webDir -> `frontend/dist`).
- **GitHub Actions** workflow que compila un APK `debug` automáticamente.

## Pasos locales (rápido)
1. Node 18+ y JDK 11 instalados.
2. `cd frontend && npm install && npm run build`
3. En la raíz: `npm install && npx cap sync android`
4. `cd android && ./gradlew assembleDebug`
5. APK en `android/app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
- Sube todo el repo a GitHub.
- Ve a **Actions** > **Build Android APK** > **Run workflow**.
- Descarga el artefacto **gamebet-apk**.

## Variables de entorno (backend)
Crea `backend/.env` (opcional):
```
PORT=4000
ADMIN_EMAIL=admin@gamebet.test
JWT_SECRET=supersecretkey
```
