import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
dotenv.config()

const app = express()
app.use(cors())
app.use(express.json())

const PORT = process.env.PORT || 4000

let users = [
  { id: 1, email: 'juan@email.com', verified: true, balance: 45250 }
]

app.get('/', (req, res) => {
  res.json({ ok: true, service: 'gamebet-backend' })
})

app.get('/api/me', (req, res) => {
  res.json(users[0])
})

app.post('/api/notify', (req, res) => {
  // Simula guardar un mensaje del sistema
  console.log('Notify:', req.body)
  res.json({ ok: true })
})

app.listen(PORT, () => console.log(`Backend listening on ${PORT}`))
