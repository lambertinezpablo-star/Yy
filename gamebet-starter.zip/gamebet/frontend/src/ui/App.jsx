import React, { useEffect, useState } from 'react'

function Banner() {
  return (
    <header className="text-white text-center py-6">
      <h1 className="text-3xl font-bold">GameBet</h1>
      <p className="opacity-90">Plataforma de retos, wallet y verificación</p>
    </header>
  )
}

function Card({ title, children }) {
  return (
    <div className="bg-white/90 rounded-2xl shadow p-4 border">
      <h2 className="font-bold mb-2">{title}</h2>
      <div>{children}</div>
    </div>
  )
}

function PendingMessages() {
  const [messages, setMessages] = useState([
    { id: 1, type: 'info', text: 'Perfil pendiente de verificación.' },
    { id: 2, type: 'success', text: 'Depósito de $50.000 confirmado.' }
  ]);
  return (
    <Card title="Bandeja de mensajes">
      <ul className="space-y-2">
        {messages.map(m => (
          <li key={m.id} className={`p-3 rounded ${m.type === 'success' ? 'bg-green-50 border border-green-200 text-green-700' : 'bg-blue-50 border border-blue-200 text-blue-700'}`}>
            {m.text}
          </li>
        ))}
      </ul>
    </Card>
  )
}

export default function App() {
  const [balance, setBalance] = useState(45250)

  useEffect(() => {
    // placeholder: cargar datos iniciales
  }, [])

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <Banner />
      <div className="grid md:grid-cols-2 gap-4">
        <Card title="Wallet">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold text-gray-800">${'{'}balance.toLocaleString('es-CO'){'}'} COP</div>
            <div className="space-x-2">
              <button className="px-3 py-2 rounded-lg bg-indigo-600 text-white">Recargar</button>
              <button className="px-3 py-2 rounded-lg bg-orange-500 text-white">Retirar</button>
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-2">Comisión por retiro o reto: 3–5%</p>
        </Card>
        <PendingMessages />
      </div>

      <div className="grid md:grid-cols-3 gap-4 mt-4">
        <Card title="Retos">
          <div className="space-y-2">
            <div className="p-3 rounded border flex items-center justify-between">
              <div>⚽ FIFA 25 — por CarlosGamer</div>
              <strong>$15.000</strong>
            </div>
            <div className="p-3 rounded border flex items-center justify-between">
              <div>🎯 COD Mobile — por ProShooter</div>
              <strong>$8.500</strong>
            </div>
          </div>
        </Card>
        <Card title="Chat">
          <div className="space-y-2 text-sm text-gray-700">
            <div className="bg-gray-100 p-2 rounded">Hola! listo para el reto</div>
            <div className="bg-indigo-600 text-white p-2 rounded ml-auto max-w-[70%]">Perfecto, te invito</div>
          </div>
        </Card>
        <Card title="Verificación KYC">
          <ul className="text-sm list-disc ml-4 space-y-1">
            <li>Sin verificación no se permite retirar.</li>
            <li>Documentos: cédula (frente/reverso), email y teléfono.</li>
            <li>Estado: Pendiente / Verificado / Rechazado.</li>
          </ul>
        </Card>
      </div>
    </div>
  )
}
